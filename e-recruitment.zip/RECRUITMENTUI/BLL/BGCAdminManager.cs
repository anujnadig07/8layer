﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using DALFACTORY;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
    public class BGCAdminManager:IBGCAdminManager
    {
        public List<IBGCAdmin> SelectBGCAdmin()
        {
            IBGCAdminDB obj = DALFACTORY.BGCAdminDBFactory.createBGCAdminDb();
            List<IBGCAdmin> list;
            try
            {
                 list = obj.SelectBGCAdmin();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return list;
        }
        public int AddBGCAdmin(IBGCAdmin e)
        {
            int i; 
            IBGCAdminDB obj = DALFACTORY.BGCAdminDBFactory.createBGCAdminDb();
            try
            {
                i = obj.AddBGCAdmin(e);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return i;

        }
        public List<IBGCAdmin> viewBGCAdmin()
        {
            IBGCAdminDB obj = DALFACTORY.BGCAdminDBFactory.createBGCAdminDb();
            try
            {
                return obj.viewBGCAdmin();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int updateBGCAdmin(IBGCAdmin e)
        {
            IBGCAdminDB obj = DALFACTORY.BGCAdminDBFactory.createBGCAdminDb();
            try
            {
                return obj.updateBGCAdmin(e);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
