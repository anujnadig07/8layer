﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DALFACTORY;
using TYPES;

namespace BLL
{
    public class BGCManager : IbgcBLL
    {
        public int Edit(IbgcBO obj)
        {
            int ret = 0;
            try
            {
                IbgcDB objdal = DALFACTORY.BgcDBFactory.createbgc();
                ret = objdal.Edit(obj);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return ret;
        }
        public DataSet Display()
        {
            DataSet dd;
            try
            {
                IbgcDB objdal = DALFACTORY.BgcDBFactory.createbgc();
                dd = objdal.Display();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dd;
        }
    }
}
