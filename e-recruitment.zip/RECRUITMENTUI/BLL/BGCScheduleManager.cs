﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using DALFACTORY;

namespace BLL
{
    public class BGCScheduleManager : IBGCScheduleManager
    {
        public List<IBGCSchedule> getBGCAdmin()
        {
            IBGCScheduleDB obj = DALFACTORY.BGCScheduleDBFactory.createBGCScheduleDB();
            List<IBGCSchedule> list;
            try
            {
                list = obj.getBGCAdmin();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return list;

        }
        public int updateBGCSchedule(IBGCSchedule obj1)
        {
            IBGCScheduleDB obj = DALFACTORY.BGCScheduleDBFactory.createBGCScheduleDB();
            int i;
            try
            {
                i = obj.updateBGCSchedule(obj1);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return i;


        }
        public int deleteBGCSchedule(IBGCSchedule e)
        {
            IBGCScheduleDB obj = DALFACTORY.BGCScheduleDBFactory.createBGCScheduleDB();
            int i;
            try
            {
                i = obj.deleteBGCSchedule(e);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return i;
        }
    }
}
