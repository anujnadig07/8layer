﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using DALFACTORY;
using System.Data;

namespace BLL
{
    public class EmployeeManager : IEmployeeBLL
    {

        public int AddEmployee(IEmployeeBO obj)
        {
            int a = 0;
            IEmployeeDB objdb = DALFACTORY.EmployeeDBFactory.createemployee();
            try
            {

                a = objdb.AddEmployee(obj);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return a;

        }
        public DataSet ViewEmployee()
        {
            DataSet a;
            IEmployeeDB objdb = DALFACTORY.EmployeeDBFactory.createemployee();
            try
            {
                a = objdb.ViewEmployee();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return a;
        }
        public DataSet GetcandidateDetails()
        {
            DataSet a;
            IEmployeeDB objdb = DALFACTORY.EmployeeDBFactory.createemployee();
            try
            {
                a = objdb.GetcandidateDetails();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return a;
        }
        public List<IEmployeeBO> ReadEmployee()
        {
            IEmployeeDB obj1 = DALFACTORY.EmployeeDBFactory.createemployee();
            List<IEmployeeBO> list;
            try
            {
                list = obj1.ReadEmployee();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return list;
        }
        public List<IEmployeeBO> Readprojectid()
        {
            IEmployeeDB obj1 = DALFACTORY.EmployeeDBFactory.createemployee();
            List<IEmployeeBO> list;
            try
            {

                list = obj1.Readprojectid();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return list;
        }

    }
}
