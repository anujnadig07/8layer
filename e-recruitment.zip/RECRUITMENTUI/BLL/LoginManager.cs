﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DALFACTORY;
using TYPES;

namespace BLL
{
    public class LoginManager : ILoginBLL
    {
        public ILoginBO getPassword(ILoginBO e)
        {
            ILoginDB obj = DALFACTORY.LoginDBFactory.createEmployeeDB();
            try
            {
                return obj.getPassword(e);
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }
        public int updatePassword(ILoginBO e)
        {

            ILoginDB obj = DALFACTORY.LoginDBFactory.createEmployeeDB();
            try
            {
                return obj.updatePassword(e);
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }
        public bool isHR(int a)
        {
            ILoginDB obj = DALFACTORY.LoginDBFactory.createEmployeeDB();
            try
            {
                return obj.isHR(a);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public bool isUnitHead(int a)
        {
            ILoginDB obj = DALFACTORY.LoginDBFactory.createEmployeeDB();
            try
            {
                return obj.isUnitHead(a);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public int isBGCAdmin(int a)
        {
            ILoginDB obj = DALFACTORY.LoginDBFactory.createEmployeeDB();
            try
            {
                return obj.isBGCAdmin(a);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
