﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BLL;

namespace BLLFACTORY
{
    public class BGCAdminManagerFactory
    {
        public static IBGCAdminManager cerateBGCAdminManager()
        {
            IBGCAdminManager o = new BGCAdminManager();
            return o;
        }
    }
}
