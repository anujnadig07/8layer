﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL;
using TYPES;

namespace BLLFACTORY
{
    public class BGCManagerFactory
    {
        public static IbgcBLL CreateBo_obj()
        {
            IbgcBLL obj = new BGCManager();
            return obj;
        }
    }
}
