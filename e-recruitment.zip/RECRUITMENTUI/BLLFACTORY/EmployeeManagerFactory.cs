﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BLL;

namespace BLLFACTORY
{
    public class EmployeeManagerFactory
    {
        public static IEmployeeBLL createemployee()
        {
            IEmployeeBLL obj1 = new EmployeeManager();
            return obj1;
        }
    }
}
