﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL;
using TYPES;

namespace BLLFACTORY
{
    public class LoginMangerFactory
    {
        public static ILoginBLL createEmployeeManager()
        {
            ILoginBLL obj = new LoginManager();
            return obj;
        }
    }
}
