﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;

namespace BO
{
    public class BGCAdmin:IBGCAdmin
    {
        int employee_Id;
        int admin_Id;
        int status;
        DateTime statuschangetime;
        public int Employee_Id { get { return employee_Id; } set { employee_Id = value; } }
        public int AdminID { get { return admin_Id; } set { admin_Id = value; } }
        public int Status { get { return status; } set { status = value; } }
        public DateTime StatusChangeTime { get { return statuschangetime; } set { statuschangetime = value; } }
    }
}
