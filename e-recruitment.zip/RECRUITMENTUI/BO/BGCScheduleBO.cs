﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;

namespace BO
{
    public class BGCScheduleBO : IBGCSchedule
    {
        int administratorID;
        int bgcID;
        DateTime startDate;
        DateTime endDate;

        public int AdministratorID { get { return administratorID; } set { administratorID = value; } }
        public int BgcID { get { return bgcID; } set { bgcID = value; } }
        public DateTime StartDate { get { return startDate; } set { startDate = value; } }
        public DateTime EndDate { get { return endDate; } set { endDate = value; } }


    }
}
