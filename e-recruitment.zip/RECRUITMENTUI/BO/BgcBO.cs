﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;

namespace BO
{
    public class BgcBO : IbgcBO
    {
        int bgcid;
        int bgcteststatus;
        int candidateID;
        int teststatus;
        string remarks;

        public int CandidateID { get { return candidateID; } set { candidateID = value; } }
        public int BGCID
        { get { return bgcid; } set { bgcid = value; } }

        public int BGCTESTSTATUS
        { get { return bgcteststatus; } set { bgcteststatus = value; } }

        public int TestStatus { get { return teststatus; } set { teststatus = value; } }

        public string Remarks
        { get { return remarks; } set { remarks = value; } }

        public BgcBO()
        { }
        public BgcBO(int bgcid, int bgcteststatus)
        {
            this.bgcid = bgcid;
            this.bgcteststatus = bgcteststatus;
        }


    }
}
