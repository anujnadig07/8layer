﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;

namespace BO
{
    public class LoginBO : ILoginBO
    {
        int userid;
        string password;
        public int Userid { get { return userid; } set { userid = value; } }
        public string Password { get { return password; } set { password = value; } }
    }
}
