﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BO;

namespace BOFACTORY
{
    public class BOFactory
    {
        public static IBGCAdmin createbgcadmin()
        {
            IBGCAdmin obj = new BGCAdmin();
            return obj;
        }
    }
}
