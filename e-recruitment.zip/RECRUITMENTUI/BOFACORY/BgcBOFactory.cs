﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BO;

namespace BOFACTORY
{
    public class BgcBOFactory
    {
        public static IbgcBO createbgc()
        {
            IbgcBO obj = new BgcBO();
            return obj;
        }
    }
}
