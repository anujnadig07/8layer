﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BO;

namespace BOFACTORY
{
    public class EmployeeBOFactory
    {

        public static IEmployeeBO createEmployee()
        {
            IEmployeeBO obj = new EmployeeBO();
            return obj;
        }
    }
}
