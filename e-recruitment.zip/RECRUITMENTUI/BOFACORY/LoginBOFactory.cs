﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BO;

namespace BOFACTORY
{
    public class LoginBOFactory
    {
        public static ILoginBO createEmployeeBO()
        {
            ILoginBO obj = new LoginBO();
            return obj;
        }
    }
}
