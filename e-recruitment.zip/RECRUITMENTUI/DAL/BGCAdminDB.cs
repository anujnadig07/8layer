﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BOFACTORY;
using System.Data;
using System.Data.SqlClient;


namespace DAL
{
    public class BGCAdminDB:IBGCAdminDB
    {
        public List<IBGCAdmin> SelectBGCAdmin()
        {
            List<IBGCAdmin> BGCList =new List<IBGCAdmin>();
            SqlConnection conn=new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand cmd = new SqlCommand("sp_selectBGCAdmin", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int i = Convert.ToInt32(reader["Employee_ID"]);
                    IBGCAdmin obj = BOFACTORY.BOFactory.createbgcadmin();
                    obj.Employee_Id = i;
                    BGCList.Add(obj);
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                //if (conn.State = ConnectionState.Open)
                    conn.Close();
            }
            
            return BGCList;            
        }
        public int AddBGCAdmin(IBGCAdmin obj)
        {
            int i;
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand cmd = new SqlCommand("sp_addBGCAdmin", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("Employee_ID", obj.Employee_Id);
                cmd.Parameters.AddWithValue("status_Admin", obj.Status);
                cmd.Parameters.AddWithValue("statuschangetime", obj.StatusChangeTime);
                connection.Open();
                i = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
                return i;
            
        }
        public List<IBGCAdmin> viewBGCAdmin()
        {
            List<IBGCAdmin> BGCAdmin = new List<IBGCAdmin>();
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand cmd = new SqlCommand("sp_viewBGCAdmin", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int employeeid = Convert.ToInt16(reader["Employee_ID"]);
                    int i = Convert.ToInt16(reader["Administrator_Id"]);
                    int status = Convert.ToInt16(reader["status_Admin"]);
                    DateTime date = Convert.ToDateTime(reader["statuschangetime"]);
                    IBGCAdmin obj = BOFACTORY.BOFactory.createbgcadmin();
                    obj.Employee_Id = employeeid;
                    obj.StatusChangeTime = date;
                    obj.Status = status;
                    obj.AdminID = i;
                    BGCAdmin.Add(obj);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return BGCAdmin;

        }
        public int updateBGCAdmin(IBGCAdmin obj)
        {
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            int i;
            try
            {
                SqlCommand cmd = new SqlCommand("sp_updateBGCAdmin", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AdministratorID", obj.AdminID);
                cmd.Parameters.AddWithValue("@Status", obj.Status);
                cmd.Parameters.AddWithValue("@Date", obj.StatusChangeTime);
                connection.Open();
                i = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return i;
        }
    }
}
