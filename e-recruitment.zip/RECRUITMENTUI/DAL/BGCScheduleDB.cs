﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BOFACTORY;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class BGCScheduleDB : IBGCScheduleDB
    {
        public List<IBGCSchedule> getBGCAdmin()
        {
            List<IBGCSchedule> BGClist = new List<IBGCSchedule>();
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand cmd = new SqlCommand("sp_getBGCAdmin", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {

                    int BGCID = Convert.ToInt32(reader["BGC_Id"]);
                    DateTime startDate = Convert.ToDateTime(reader["FromDate"]);
                    DateTime endDate = Convert.ToDateTime(reader["ToDate"]);
                    int administatorID = Convert.ToInt32(reader["Administrator_Id"]);
                    IBGCSchedule obj = BOFACTORY.BGCScheduleBOFactory.createBGCSchedule();

                    obj.AdministratorID = administatorID;
                    obj.BgcID = BGCID;
                    obj.StartDate = startDate;
                    obj.EndDate = endDate;
                    BGClist.Add(obj);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return BGClist;
        }
        public int updateBGCSchedule(IBGCSchedule e)
        {
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            SqlCommand cmd = new SqlCommand("sp_updateBGCSchedule", connection);
            int i;
            try
            {
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AdministratorID", e.AdministratorID);
                cmd.Parameters.AddWithValue("@StartDate", e.StartDate);
                cmd.Parameters.AddWithValue("@EndDate", e.EndDate);
                connection.Open();
                i = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return i;
        }

        public int deleteBGCSchedule(IBGCSchedule e)
        {
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            SqlCommand cmd = new SqlCommand("sp_deleteBGCSchedule", connection);
            int i;
            try
            {

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AdministratorID", e.AdministratorID);
                connection.Open();
                i = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return i;
        }
    }
}
