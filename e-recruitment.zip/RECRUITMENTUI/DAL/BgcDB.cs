﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

using TYPES;
using BOFACTORY;

namespace DAL
{
    public class BgcDB : IbgcDB
    {
        public int Edit(IbgcBO obj)
        {
            int ret = 0;
            SqlConnection conn = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand command = new SqlCommand("sp_update10", conn);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Connection = conn;
                command.Parameters.AddWithValue("@candidateID", obj.CandidateID);
                command.Parameters.AddWithValue("@bgcteststatus", obj.BGCTESTSTATUS);
                conn.Open();
                ret = command.ExecuteNonQuery();
                updatestatus_BGCnotcleared_2(obj);
                updatestatus_BGCcleared(obj);
                updateremarks_bgcnotcleared(obj);
                updateremarks_bgccleared(obj);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                conn.Close();
            }
            return ret;
        }
        private void updateremarks(IbgcBO obj)
        {
            SqlConnection conn = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand command = new SqlCommand("sp_updateremarks10", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = conn;
                command.Parameters.AddWithValue("@bgcteststatus", obj.BGCTESTSTATUS);
                command.Parameters.AddWithValue("@remarks", obj.Remarks);
                command.Parameters.AddWithValue("@candidateprofileid", obj.CandidateID);
                conn.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

        }
        public void updatestatus_BGCcleared(IbgcBO obj)
        {
            SqlConnection conn = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand command = new SqlCommand("sp_updatecleared10", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "sp_updatecleared10";
                command.Connection = conn;
                conn.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            

        }

        public void updatestatus_BGCnotcleared_2(IbgcBO obj)
        {
            SqlConnection conn = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand command = new SqlCommand("sp_updatenotcleared10", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "sp_updatenotcleared10";
                command.Connection = conn;
                conn.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

        }
        public void updateremarks_bgccleared(IbgcBO obj)
        {
            SqlConnection conn = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand command = new SqlCommand("sp_updateremarks3", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "sp_updateremarks3";
                command.Parameters.AddWithValue("@bgctestatus", obj.BGCTESTSTATUS);
                //command.Parameters.AddWithValue("@remarks", obj.Remarks);
                command.Parameters.AddWithValue("@CandidateID", obj.CandidateID);
                command.Connection = conn;
                conn.Open();
                command.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
            conn.Close();
            }
        }
        public void updateremarks_bgcnotcleared(IbgcBO obj)
        {
            SqlConnection conn = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand command = new SqlCommand("sp_notupdateremarks3", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "sp_notupdateremarks3";
                command.Parameters.AddWithValue("@CandidateID", obj.CandidateID);
                command.Parameters.AddWithValue("@remarks", obj.Remarks);
                command.Connection = conn;
                conn.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        }

        public DataSet Display()
        {
            SqlConnection conn = new SqlConnection(DataUtility.dataUtilities());
            DataSet ds;
            try
            {
                SqlCommand command = new SqlCommand("sp_view10", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "sp_view10";
                command.Connection = conn;
                SqlDataAdapter adapter = new SqlDataAdapter();
                 ds = new DataSet();
                adapter.SelectCommand = command;
                conn.Open();
                adapter.Fill(ds);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return ds;

        }
    }
}
