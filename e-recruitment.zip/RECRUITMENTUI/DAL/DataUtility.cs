﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace DAL
{
    class DataUtility
    {
        public static string dataUtilities()
        {
            string str = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            return str;
        }
    }
}
