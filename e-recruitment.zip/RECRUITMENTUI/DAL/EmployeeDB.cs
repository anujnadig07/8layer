﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BOFACTORY;
using System.Data;
using System.Data.SqlClient;
using BO;


namespace DAL
{
    public class EmployeeDB : IEmployeeDB
    {
        public int AddEmployee(IEmployeeBO obj)
        {
            int a = 0;
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            try
            {
                SqlCommand command = new SqlCommand("Add_employee_module3", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                //command.CommandText = "Add_employee_module3";
                command.Connection = connection;
                command.Parameters.AddWithValue("@Empname", obj.EmployeeName);
                command.Parameters.AddWithValue("@Dob", obj.DOB);
                command.Parameters.AddWithValue("@Doj", obj.DOJ);
                command.Parameters.AddWithValue("@Location", obj.Division);
                command.Parameters.AddWithValue("@designation", obj.Designation);
                command.Parameters.AddWithValue("@Ctc", obj.CTC);
                command.Parameters.AddWithValue("@gender", obj.Gender);
                command.Parameters.AddWithValue("@unithead", obj.UnitHeadID);
                command.Parameters.AddWithValue("@projectid", obj.ProjectID);
                command.Parameters.AddWithValue("@ishr", obj.IsHR);
                command.Parameters.AddWithValue("@isunithead", obj.IsUnitHead);
                command.Parameters.AddWithValue("@empid", 0);
                command.Parameters["@empid"].Direction = ParameterDirection.Output;
                connection.Open();
                a = command.ExecuteNonQuery();
                if (a == 1)
                {
                    return (Convert.ToInt32(command.Parameters["@empid"].Value));
                }

                else { return a; }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }



            //connection code
        
        }
        public DataSet GetcandidateDetails()
        {
            //connection code
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            DataSet ds;
            try
            {
                SqlCommand command = new SqlCommand("sp_GetCandidate", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                //command.CommandText = "Employee_VIEW";
                command.Connection = connection;
                SqlDataAdapter ad = new SqlDataAdapter();
                ad.SelectCommand = command;
                ds = new DataSet();
                ad.Fill(ds);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }

        public DataSet ViewEmployee()
        {
            //connection code
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            DataSet ds;
            try
            {
                SqlCommand command = new SqlCommand("Employee_VIEW", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                //command.CommandText = "Employee_VIEW";
                command.Connection = connection;
                SqlDataAdapter ad = new SqlDataAdapter();
                ad.SelectCommand = command;
                ds = new DataSet();
                ad.Fill(ds);
            }
            catch(Exception ex)
            {
                throw ex;
            }

            return ds;
        }

        public List<IEmployeeBO> ReadEmployee()
        {
            List<IEmployeeBO> obj2 = new List<IEmployeeBO>();
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            //DataSet ds;
            try
            {
                SqlCommand command = new SqlCommand("select_Unithead", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                //command.CommandText = "select_Unithead";
                command.Connection = connection;
                connection.Open();
                SqlDataReader sdr = command.ExecuteReader();
                //Read the Values fetched.
                while (sdr.Read())
                {
                    int id = Convert.ToInt32(sdr["Employee_ID"]);
                    EmployeeBO obj3 = new EmployeeBO(id);
                    obj2.Add(obj3);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return obj2;

        }
        public List<IEmployeeBO> Readprojectid()
        {
            List<IEmployeeBO> obj2 = new List<IEmployeeBO>();
             SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            //DataSet ds;
             try
             {
                 SqlCommand command = new SqlCommand("selectprojectid", connection);
                 command.CommandType = System.Data.CommandType.StoredProcedure;
                 //command.CommandText = "selectprojectid";
                 command.Connection = connection;
                 connection.Open();
                 SqlDataReader sdr = command.ExecuteReader();
                 //Read the Values fetched.
                 while (sdr.Read())
                 {
                     int id = Convert.ToInt32(sdr["Project_ID"]);
                     EmployeeBO obj3 = new EmployeeBO(id);
                     obj2.Add(obj3);
                 }
             }
             catch (Exception ex)
             {
                 throw ex;
             }
             finally
             {
                 connection.Close();
             }
            return obj2;

        }


    }
}
