﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BOFACTORY;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;

namespace DAL
{
    public class LoginDB : ILoginDB
    {
        public ILoginBO getPassword(ILoginBO obj1)
        {
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            ILoginBO obj = BOFACTORY.LoginBOFactory.createEmployeeBO();
            try
            {
                SqlCommand cmd = new SqlCommand("sp_login", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", obj1.Userid);
                cmd.Parameters.AddWithValue("@pass_word", obj1.Password);
                connection.Open();
                int i = Convert.ToInt16(cmd.ExecuteScalar());
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    int userid = Convert.ToInt16(reader["UserName"]);
                    string password = reader["pass_word"].ToString();
                    obj.Userid = userid;
                    obj.Password = password;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return obj;
        }


        public int updatePassword(ILoginBO obj)
        {
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            int i;
            try
            {
                SqlCommand cmd = new SqlCommand("sp_updatepassword", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", obj.Userid);
                cmd.Parameters.AddWithValue("@pass_word", obj.Password);
                connection.Open();
                i = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return i;
        }


        public bool isHR(int count)
        {
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            bool i;
            try
            {
                SqlCommand cmd = new SqlCommand("sp_isHR", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                cmd.Parameters.AddWithValue("@empid", count);
                i = Convert.ToBoolean(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return i;
        }

        public bool isUnitHead(int count)
        {
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            bool i;
            try
            {
                SqlCommand cmd = new SqlCommand("sp_isUnitHead", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                cmd.Parameters.AddWithValue("@empid", count);
                i = Convert.ToBoolean(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

            return i;
        }
        public int isBGCAdmin(int count)
        {
            SqlConnection connection = new SqlConnection(DataUtility.dataUtilities());
            int i;
            try
            {
                SqlCommand cmd = new SqlCommand("sp_isBGCAdmin", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                connection.Open();
                cmd.Parameters.AddWithValue("@empid", count);
                i = Convert.ToInt16(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return i;

        }


    }
}
