﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using TYPES;
using System.Threading.Tasks;

namespace DALFACTORY
{
    public class BGCAdminDBFactory
    {
       public static IBGCAdminDB createBGCAdminDb(){
           IBGCAdminDB obj = new BGCAdminDB();
        return obj;
    }

    }
}
