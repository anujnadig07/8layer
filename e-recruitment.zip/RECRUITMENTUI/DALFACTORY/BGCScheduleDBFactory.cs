﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using DAL;

namespace DALFACTORY
{
    public class BGCScheduleDBFactory
    {
        public static IBGCScheduleDB createBGCScheduleDB()
        {
            IBGCScheduleDB obj = new BGCScheduleDB();
            return obj;
        }
    }
}
