﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using TYPES;
using System.Threading.Tasks;

namespace DALFACTORY
{
    public class EmployeeDBFactory
    {
        public static IEmployeeDB createemployee()
        {
            IEmployeeDB obj2 = new EmployeeDB();
            return obj2;
        }
    }
}
