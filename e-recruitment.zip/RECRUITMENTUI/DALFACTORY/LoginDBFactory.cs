﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using DAL;
using System.Configuration;

namespace DALFACTORY
{
    public class LoginDBFactory
    {
        public static ILoginDB createEmployeeDB()
        {
            ILoginDB obj = new LoginDB();
            return obj;
        }
    }
}
