﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BLLFACTORY;
using BOFACTORY;

namespace RECRUITMENTUI
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //lblcanid.Text = Session["canid"].ToString();
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["username"] == null)
            {
                Response.Redirect("LoginForAll.aspx");
            }
            lblid.Text ="Employee ID:"+ Session["Empid"].ToString();
            lblinfo.Text = ("Logged in as:" + Session["user"]);
            
            if (!IsPostBack)
            {
                IEmployeeBLL Obj = BLLFACTORY.EmployeeManagerFactory.createemployee();
                List<IEmployeeBO> empList = new List<IEmployeeBO>();
                empList = Obj.ReadEmployee();
                ddlunithead.DataSource = empList;
                ddlunithead.DataTextField = "unitheadID";
                ddlunithead.DataValueField = "unitheadID";
                ddlunithead.DataBind();


                empList = Obj.Readprojectid();
                ddlprojectid.DataSource = empList;
                ddlprojectid.DataTextField = "projectID";
                ddlprojectid.DataValueField = "projectID";
                ddlprojectid.DataBind();
            }
        }
        protected void ImageButton2_Click1(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HRHomePage.aspx");
        }


        protected void btnADDEmployee_Click(object sender, EventArgs e)
        {

            IEmployeeBO objbo = BOFACTORY.EmployeeBOFactory.createEmployee();
            try
            {
                objbo.EmployeeName = txtempname.Text;
                objbo.DOB = Convert.ToDateTime(txtdobcal.Text);
                objbo.DOJ = Convert.ToDateTime(txtbojcal.Text);
                objbo.Gender = rdgender.SelectedValue;
                objbo.Designation = ddldesignation.SelectedValue;
                objbo.Division = ddlloc.SelectedValue;
                objbo.CTC = float.Parse(txtctc.Text);
                objbo.UnitHeadID = int.Parse(ddlunithead.SelectedValue);
                objbo.ProjectID = int.Parse(ddlprojectid.SelectedValue);
                if(ddldesignation.SelectedValue=="HR")
                {
                    objbo.IsHR = true;
                }
                else if (ddldesignation.SelectedValue == "Unit Head")
                {
                    objbo.IsUnitHead = true;
                }
                
                //objbo.IsHR = chkIshr.Checked;
                //objbo.IsUnitHead = chkIsunithead.Checked;
                DateTime currrentday = DateTime.Now;
                bool ishr = objbo.IsHR;
                bool isunithead = objbo.IsUnitHead;
                int days = currrentday.Year - objbo.DOJ.Year;
                if (days >= 1)
                {

                    float salary = objbo.CTC + (150000 * days);
                    objbo.CTC = salary;
                    //Response.Write("days " + salary);
                }
                //if(ishr)
                //{
                //    objbo.UnitHeadID = ;
                //}
                //if(isunithead)
                //{
                //    objbo.UnitHeadID = 0;
                //}

                IEmployeeBLL objbll = BLLFACTORY.EmployeeManagerFactory.createemployee();
                int a = objbll.AddEmployee(objbo);
                string str=("Employee Added and Employee ID is" + a);
                Page.ClientScript.RegisterStartupScript(this.GetType(), "alertkey", "<script> alert('"+str+"')</script>", false);
            }
            catch(Exception ex)
            {
                string strmsg = ex.Message;
                Response.Write("Error Message:" + strmsg);
            }
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            caldob.Visible = true;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtdobcal.Text =caldob.SelectedDate.ToShortDateString();
            caldob.Visible = false;
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            caldoj.Visible = true;
        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            txtbojcal.Text = caldoj.SelectedDate.ToShortDateString();
            caldoj.Visible = false;

        }

        protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
        {
            
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("HRHomePage.aspx");
        }

        protected void ImageButton1_Click2(object sender, ImageClickEventArgs e)
        {
            Session["username"] = null;
            Response.Redirect("LoginForAll.aspx");
        }

        protected void ImageButton2_Click2(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HRHomePage.aspx");

        }

       

       
    }
}