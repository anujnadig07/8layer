﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BOFACTORY;
using BLLFACTORY;

namespace RECRUITMENTUI
{
    public partial class WebForm4 : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Text = "Employee ID:" + Session["Empid"].ToString();
            lblinfo.Text = "Logged in as" + Session["user"].ToString();
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["username"] == null)
            {
                Response.Redirect("LoginForAll.aspx");
            }
            if (!IsPostBack)
                bindBGCAdmin();
        }
        protected void bindBGCAdmin()
        {
            IBGCAdminManager obj2 = BLLFACTORY.BGCAdminManagerFactory.cerateBGCAdminManager();
            grdapprove.DataSource = obj2.viewBGCAdmin();
            grdapprove.DataBind();


        }
        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdapprove.Columns[3].Visible = true;
            grdapprove.EditIndex = e.NewEditIndex;
            bindBGCAdmin();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdapprove.EditIndex = -1;
            bindBGCAdmin();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                grdapprove.Columns[3].Visible = false;
                GridViewRow row = grdapprove.Rows[e.RowIndex];
                HiddenField hdnId = (HiddenField)row.FindControl("hdnID");
                DropDownList ddlbgcapprove = (DropDownList)row.FindControl("ddlbgcstatus");
                //TextBox txtStatus = (TextBox)row.FindControl("txtStatus");
               
                int status = Convert.ToInt16(ddlbgcapprove.SelectedValue);
                DateTime statuschangetime = DateTime.Now;
                IBGCAdmin obj = BOFACTORY.BOFactory.createbgcadmin();
                obj.AdminID = Convert.ToInt16(hdnId.Value);
                obj.Status = status;
                obj.StatusChangeTime = statuschangetime;
                IBGCAdminManager obj2 = BLLFACTORY.BGCAdminManagerFactory.cerateBGCAdminManager();
                int i = obj2.updateBGCAdmin(obj);
                grdapprove.EditIndex = -1;
                bindBGCAdmin();

            }

            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void grdapprove_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //DropDownList ddlbgc = (DropDownList)e.Row.FindControl("ddlbgcstatus");

                Label type = (Label)e.Row.FindControl("lblStatus");

                //Label type2 = (Label)e.Row.FindControl("Labelstatus");
                if (type.Text == "0")
                {

                    e.Row.Cells[2].Text = "Pending";
                }

                else if (type.Text == "1")
                {

                    e.Row.Cells[2].Text = "Approved";
                }

                else if (type.Text == "2")
                {

                    e.Row.Cells[2].Text = "On leave";
                }
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("HRHomePage.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Session["username"] = null;
            Response.Redirect("LoginForAll.aspx");

        }

        protected void grdapprove_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdapprove.PageIndex = e.NewPageIndex;
            grdapprove.DataBind();
        }
    }
}
