﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BOFACTORY;
using BLLFACTORY;

namespace RECRUITMENTUI
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblinfo.Text = "Logged in as" + Session["user"].ToString();
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["username"] == null)
            {
                Response.Redirect("LoginForAll.aspx");
            }

            if (!IsPostBack)
            {
                IBGCAdminManager obj = BLLFACTORY.BGCAdminManagerFactory.cerateBGCAdminManager();
                List<IBGCAdmin> list = obj.SelectBGCAdmin();
                ddladmin.DataSource = list;
                ddladmin.DataTextField = "Employee_ID";
                ddladmin.DataValueField = "Employee_ID";
                ddladmin.DataBind();
            }
            lblerrormessage.Visible = false;
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            IBGCAdminManager obj3 = BLLFACTORY.BGCAdminManagerFactory.cerateBGCAdminManager();
            List<IBGCAdmin> list = obj3.viewBGCAdmin();
            int i = 0;
            try
            {

                foreach (IBGCAdmin bgc in list)
                {

                    if (bgc.Employee_Id == Convert.ToInt16(ddladmin.SelectedItem.Value))
                        i = 1;
                }

                if (i == 0)
                {
                    IBGCAdminManager obj = BLLFACTORY.BGCAdminManagerFactory.cerateBGCAdminManager();
                    IBGCAdmin obj1 = BOFACTORY.BOFactory.createbgcadmin();
                    obj1.Employee_Id = Convert.ToInt16(ddladmin.SelectedItem.Value);
                    obj1.StatusChangeTime = DateTime.Now;
                    obj.AddBGCAdmin(obj1);
                    lblerrormessage.Visible = true;
                    lblerrormessage.Text = "Admin added ";

                    //IBGCAdminManager obj2 = BLLFACTORY.BGCAdminManagerFactory.cerateBGCAdminManager();
                    //GridView1.DataSource = obj2.viewBGCAdmin();
                    //GridView1.DataBind();
                }
                else
                {
                    lblerrormessage.Visible = true;
                    lblerrormessage.Text = "admin exists";
                }
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);
            }
            
        }

        protected void ImageButton2_Click2(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HRHomePage.aspx");
        }

        protected void ImageButton1_Click2(object sender, ImageClickEventArgs e)
        {
            Session["username"] = null;
            Response.Redirect("LoginForAll.aspx");
        }

        

    }
 }
    
