﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BLLFACTORY;
using BOFACTORY;
using System.Data;

namespace RECRUITMENTUI
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblinfo.Text = "Logged in as" + Session["user"].ToString();
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["username"] == null)
            {
                Response.Redirect("LoginForAll.aspx");
            }

            if (!IsPostBack)
            {
                //BindData();
            }
        }
        public void databind()
        {
            DataSet ds;
            IbgcBLL obj = BLLFACTORY.BGCManagerFactory.CreateBo_obj();
            ds = obj.Display();
            grdeditbgctest.DataSource = ds;
            grdeditbgctest.DataBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            grdeditbgctest.Visible = true;
            grdDisplay.Visible = false;
            databind();
        }

        protected void grdeditbgctest_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdeditbgctest.Columns[3].Visible = false;
            grdeditbgctest.EditIndex = -1;
            databind();

        }

        protected void grdeditbgctest_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            grdeditbgctest.Columns[3].Visible = false;
            GridViewRow row = grdeditbgctest.Rows[e.RowIndex];
            Label Label = (Label)row.FindControl("lblcandidateid");
            DropDownList ddlbgc = (DropDownList)row.FindControl("ddlbgcstatus");
            //TextBox TextBox2 = (TextBox)row.FindControl("TextBox2");
            //Label labeltest = (Label)row.FindControl("teststatus");
            TextBox txtboxremarks = (TextBox)row.FindControl("txtremarks");

            IbgcBO obj = BOFACTORY.BgcBOFactory.createbgc();
            obj.CandidateID = int.Parse(Label.Text);
            obj.BGCTESTSTATUS = Convert.ToInt16(ddlbgc.SelectedValue);
            obj.Remarks = txtboxremarks.Text;
            //obj.TestStatus = Convert.ToInt16(labeltest.Text);

            IbgcBLL obj1 = BLLFACTORY.BGCManagerFactory.CreateBo_obj();
            obj1.Edit(obj);
            grdeditbgctest.EditIndex = -1;
            databind();

        }
         protected void grdeditbgctest_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                Label type = (Label)e.Row.FindControl("lblteststatus");

                //Label type2 = (Label)e.Row.FindControl("Labelstatus");
                if (type.Text == "5")
                {

                    e.Row.Cells[2].Text = "Pending";
                }

                else if (type.Text == "6")
                {

                    e.Row.Cells[2].Text = "cleared";
                }

               
                if (type.Text == "5")
                {

                    type.Text = "Awaiting BGC";
                }

                else if (type.Text == "6")
                {

                    type.Text = "Confirmed";
                }               


            }
        }

         protected void grdDisplay_RowDataBound(object sender, GridViewRowEventArgs e)
         {
             if (e.Row.RowType == DataControlRowType.DataRow)
             {

                 Label type = (Label)e.Row.FindControl("lblteststatusdisplay");

                 //Label type2 = (Label)e.Row.FindControl("Labelstatus");
                 if (type.Text == "5")
                 {

                     e.Row.Cells[2].Text = "Pending";
                 }

                 else if (type.Text == "6")
                 {

                     e.Row.Cells[2].Text = "cleared";
                 }

                 if (type.Text == "5")
                 {

                     type.Text = "Awaiting BGC";
                 }

                 else if (type.Text == "6")
                 {

                     type.Text = "Confirmed";
                 }

             }
         }
         protected void grdeditbgctest_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdeditbgctest.Columns[3].Visible = true;
            grdeditbgctest.EditIndex = e.NewEditIndex;
            databind();
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            grdeditbgctest.Visible = false;
            grdDisplay.Visible = true;
            DataSet ds;
            IbgcBLL obj = BLLFACTORY.BGCManagerFactory.CreateBo_obj();
            ds = obj.Display();
            grdDisplay.DataSource = ds;
            grdDisplay.DataBind();
        }

        protected void ImageButton1_Click2(object sender, ImageClickEventArgs e)
        {
            Session["username"] = null;
            Response.Redirect("LoginForAll.aspx");
        }

    }
}