﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using DALFACTORY;
using System.Data;

namespace BLL
{
    public class EmployeeBLL:IEmployeeBLL
    {

        public int AddEmployee(IEmployeeBO obj)
        {
            int a = 0;
            IEmployeeDB objdb = DALFACTORY.EmployeeDBFactory.createemployee();
            
            DateTime currrentday = DateTime.Now;
            int days = currrentday.Year - obj.DOJ.Year;
            if(days > 365)
            {
                float salary = obj.CTC + 150000;
                obj.CTC = salary;
            }
            a = objdb.AddEmployee(obj);
           
            return a;
        }
        public DataSet ViewEmployee()
        {
            DataSet a;
            IEmployeeDB objdb = DALFACTORY.EmployeeDBFactory.createemployee();
            a = objdb.ViewEmployee();
            return a;
        }
        public List<IEmployeeBO> ReadEmployee()
        {
            IEmployeeDB obj1 =DALFACTORY.EmployeeDBFactory.createemployee();
            List<IEmployeeBO> list = obj1.ReadEmployee();
            return list;
        }
        public List<IEmployeeBO> Readprojectid()
        {
            IEmployeeDB obj1 = DALFACTORY.EmployeeDBFactory.createemployee();
            List<IEmployeeBO> list = obj1.Readprojectid();
            return list;
        }
       
    }
}
