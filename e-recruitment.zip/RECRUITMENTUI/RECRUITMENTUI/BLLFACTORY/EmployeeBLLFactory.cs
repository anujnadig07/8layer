﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BLL;

namespace BLLFACTORY
{
    public class EmployeeBLLFactory
    {
        public static IEmployeeBLL createemployee()
        {
            IEmployeeBLL obj1 = new EmployeeBLL();
            return obj1;
        }
    }
}
