﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;

namespace BO
{
    public class EmployeeBO:IEmployeeBO
    {
        int employeeID;
        string empname;
        int unitheadID;
        int projectID;
        bool ishr;
        bool isunithead;
        string division;
        DateTime dob;
        DateTime doj;
        string gender;
        float ctc;
        string designation;

        public int EmployeeID
        {
            get { return employeeID; }
            set { employeeID = value; }
        }
        public string EmployeeName 
        {
            get { return empname; }
            set { empname = value; }
        }

        public int UnitHeadID 
        {
            get { return unitheadID; }
            set { unitheadID = value;} 
        }
        public int ProjectID 
        {
            get { return projectID; }
            set { projectID = value;}
        }
        public bool IsHR
        {
            get { return ishr; }
            set { ishr = value; }
 
        }
       public bool IsUnitHead
        {
            get { return isunithead; }
            set { isunithead = value; }
       }
        public string Division
       {
           get { return division; }
           set { division = value; }
        }
        public DateTime DOB
        {
            get { return dob; }
            set { dob = value; }
        }
        public DateTime DOJ 
        {
            get { return doj; }
            set { doj = value; }
        }
        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        public float CTC 
        {
            get { return ctc; }
            set { ctc = value; } 
        }
        public string Designation 
        {
            get { return designation; }
            set { designation = value; }
        }
        public EmployeeBO(int unithead)
        {
            this.unitheadID = unithead;
            this.projectID = unithead;
        }
        public EmployeeBO() { }
    }
}
