﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BOFACTORY;
using BLLFACTORY;

namespace RECRUITMENTUI
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            
            string password = txtNewpassword.Text;
            int userid = 0;
            ILoginBO obj = BOFACTORY.LoginBOFactory.createEmployeeBO();
            try
            {
                if (Session["Empid"] != null)
                    userid = Convert.ToInt16(Session["Empid"]);

                obj.Userid = userid;
                obj.Password = password;
                ILoginBLL obj1 = BLLFACTORY.LoginMangerFactory.createEmployeeManager();
                int i = obj1.updatePassword(obj);
                if (i == 1)
                {
                    lblerrormsg.Visible = true;
                    lblerrormsg.Text = "password changed and login now";
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}