﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BOFACTORY;
using BLLFACTORY;
using System.Data;


namespace RECRUITMENTUI
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblinfo.Text = "Logged in as" + Session["user"].ToString();
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["username"] == null)
            {
                Response.Redirect("LoginForAll.aspx");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("BGCAdminManager.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewEmployee.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddEmployee.aspx");
        }
        
        protected void btnShedulebgcadmin_Click(object sender, EventArgs e)
        {
            Response.Redirect("ScheduleBGCAdministrator.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("BGCAdminManager.aspx");
        }

        

        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            IEmployeeBLL objbll=BLLFACTORY.EmployeeManagerFactory.createemployee();
            DataSet ds=objbll.GetcandidateDetails();
            grdcandidate.DataSource = ds;
            grdcandidate.DataBind();
        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("ViewEmployee.aspx");
        }

        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("ScheduleBGCAdministrator.aspx");
        }

        protected void grdcandidate_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label canid = (Label)e.Row.FindControl("lblcanid");
                Label status = (Label)e.Row.FindControl("lblstatus");
                Session["canid"] = canid.Text;
                if (status.Text == "5")
                {
                    e.Row.Cells[1].Text = "pending";
                }
                else if(status.Text =="6")
                {
                    e.Row.Cells[1].Text = "Cleared";
                }
            }
        }

        protected void ImageButton1_Click2(object sender, ImageClickEventArgs e)
        {
            Session["username"] = null;
            Response.Redirect("LoginForAll.aspx");
        }

       

        


        

    }
}