﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BOFACTORY;
using BLLFACTORY;

namespace RECRUITMENTUI
{
    public partial class LoginForAll : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtusername.Focus();
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            //if(Session["username"]==null)
            //{
            //    Response.Redirect("LoginForAll.aspx");
            //}
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            
            labelerrormessage.Visible = true;
            ILoginBLL obj = BLLFACTORY.LoginMangerFactory.createEmployeeManager();
            int username = Convert.ToInt16(txtusername.Text);
            Session["username"] = username;
            string password = txtpassword.Text;
            ILoginBO obj1 = BOFACTORY.LoginBOFactory.createEmployeeBO();
            obj1.Password = password;
            obj1.Userid = username;
            ILoginBO obj2 = obj.getPassword(obj1);
            if (obj2.Password == "tata")
            {
                Session["Empid"] = Convert.ToInt16(txtusername.Text);
                Response.Redirect("Changepassword.aspx");
            }
            else
            {
                Session["Empid"] = obj1.Userid;
            }
            if (password == obj2.Password)
            {
                if (obj.isHR(username))
                {
                    Session["Empid"] = obj1.Userid;
                    Session["user"] = "HR";
                    Response.Redirect("HRHomePage.aspx");
                }
                if (obj.isUnitHead(username))
                {
                    Session["Empid"] = obj1.Userid;
                    Session["user"] = "UNIT HEAD";
                    Response.Redirect("ApproveBGCAdmin.aspx");
                }
                if (obj.isBGCAdmin(username) > 0)
                {
                    Session["Empid"] = obj1.Userid;
                    Session["user"] = "BGC ADMIN";
                    Response.Redirect("BGCCheckTest.aspx");
                }
            }
            else
            {
                labelerrormessage.Text = "Invalid Credentials";
            }



        }
    }
}