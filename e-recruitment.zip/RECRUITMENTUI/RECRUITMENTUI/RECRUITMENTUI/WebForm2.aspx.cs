﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BLLFACTORY;
using BOFACTORY;

namespace RECRUITMENTUI
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IEmployeeBLL Obj = BLLFACTORY.EmployeeBLLFactory.createemployee();
                List<IEmployeeBO> empList = new List<IEmployeeBO>();
                empList = Obj.ReadEmployee();
                ddlunithead.DataSource = empList;
                ddlunithead.DataTextField = "unitheadID";
                ddlunithead.DataValueField = "unitheadID";
                ddlunithead.DataBind();


                empList = Obj.Readprojectid();
                ddlprojectid.DataSource = empList;
                ddlprojectid.DataTextField = "projectID";
                ddlprojectid.DataValueField = "projectID";
                ddlprojectid.DataBind();
            }
        }


        protected void Button2_Click(object sender, EventArgs e)
        {
            IEmployeeBO objbo = BOFACTORY.EmployeeBOFactory.createEmployee();
            objbo.EmployeeName = txtempname.Text;
            objbo.DOB = Convert.ToDateTime(TextBox1.Text);
            objbo.DOJ = Convert.ToDateTime(TextBox2.Text);
            objbo.Gender = rdgender.SelectedValue;
            objbo.Designation = txtdesignation.Text;
            objbo.Division = txtdesignation.Text;
            objbo.CTC = float.Parse(txtctc.Text);
            objbo.UnitHeadID=int.Parse(ddlunithead.SelectedValue);
            objbo.ProjectID = int.Parse(ddlprojectid.SelectedValue);

            IEmployeeBLL objbll = BLLFACTORY.EmployeeBLLFactory.createemployee();
            objbll.AddEmployee(objbo);

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Calendar1.Visible = true;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            TextBox1.Text =Convert.ToString(Calendar1.SelectedDate);
            Calendar1.Visible = false;
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Calendar2.Visible = true;
        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            TextBox2.Text = Convert.ToString(Calendar2.SelectedDate);
            Calendar2.Visible = false;

        }
    }
}