﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BOFACTORY;
using BLLFACTORY;

namespace RECRUITMENTUI
{
    public partial class WebForm9 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();

            if (Session["username"] == null)
            {
                Response.Redirect("LoginForAll.aspx");
            }

            if (!IsPostBack)
                bindBGCSchedule();
        }
        protected void  bindBGCSchedule()
        {
            IBGCScheduleManager obj = BLLFACTORY.BGCScheduleManagerFactory.createBGCScheduleManager();
            try
            {
                grdresult.DataSource = obj.getBGCAdmin();
                grdresult.DataBind();
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
                   
        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                GridViewRow row = grdresult.Rows[e.RowIndex];
                HiddenField hdnId = (HiddenField)row.FindControl("hdnID");
                TextBox txtStartDate = (TextBox)row.FindControl("txtStartDate");
                TextBox txtEndDate = (TextBox)row.FindControl("txtEndDate");
                IBGCSchedule obj = BOFACTORY.BGCScheduleBOFactory.createBGCSchedule();
                obj.AdministratorID = Convert.ToInt16(hdnId.Value);
                obj.StartDate = Convert.ToDateTime(txtStartDate.Text);
                obj.EndDate = Convert.ToDateTime(txtEndDate.Text);
                IBGCScheduleManager obj1 = BLLFACTORY.BGCScheduleManagerFactory.createBGCScheduleManager();
                int i = obj1.updateBGCSchedule(obj);
                grdresult.EditIndex = -1;
                bindBGCSchedule();
                if (i == 1)
                    lblresult.Text = "update sucessfull";
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                GridViewRow row = grdresult.Rows[e.RowIndex];
                HiddenField hdnId = (HiddenField)row.FindControl("hdnID");
                IBGCSchedule obj = BOFACTORY.BGCScheduleBOFactory.createBGCSchedule();
                obj.AdministratorID = Convert.ToInt16(hdnId.Value);
                IBGCScheduleManager obj1 = BLLFACTORY.BGCScheduleManagerFactory.createBGCScheduleManager();
                obj1.deleteBGCSchedule(obj);
                grdresult.EditIndex = -1;
                bindBGCSchedule();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

            grdresult.EditIndex = e.NewEditIndex;
            bindBGCSchedule();

        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdresult.EditIndex = -1;
            bindBGCSchedule();                 
    
        }

        protected void ImageButton2_Click2(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HRHomePage.aspx");
        }

        protected void ImageButton1_Click2(object sender, ImageClickEventArgs e)
        {
            Session["username"] = null;
            Response.Redirect("LoginForAll.aspx");
        }

        protected void grdresult_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {

        }



        protected void grdresult_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton l = (LinkButton)e.Row.FindControl("lnkdelete");
                l.Attributes.Add("onclick", "javascript:return " +
                "confirm('Are you sure you want to delete BGC Admin " +
                DataBinder.Eval(e.Row.DataItem, "BgcID") + "')");
            }

        }
    }
}