﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using TYPES;
using BOFACTORY;
using BLLFACTORY;


namespace RECRUITMENTUI
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmessage.Text ="Logged in as"+ Session["user"].ToString();
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();

            if (Session["username"] == null)
            {
                Response.Redirect("LoginForAll.aspx");
            }
            try
            {
                DataSet da;
                IEmployeeBLL objbll = BLLFACTORY.EmployeeManagerFactory.createemployee();
                da = objbll.ViewEmployee();
                grdViewEmployee.DataSource = da;
                grdViewEmployee.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write("Error is " + ex.Message);
            }
        }

       

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("HRHomePage.aspx"); 
        }

        protected void grdViewEmployee_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdViewEmployee.PageIndex = e.NewPageIndex;
            grdViewEmployee.DataBind();
        }

        protected void ImageButton2_Click2(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HRHomePage.aspx");

        }

        protected void ImageButton1_Click2(object sender, ImageClickEventArgs e)
        {
            Session["username"] = null;
            Response.Redirect("LoginForAll.aspx");
        }

        

        
    }
}