﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TYPES
{
   public interface IBGCAdmin
    {
       int AdminID { get; set; }
       int Status { get; set; }
       DateTime StatusChangeTime { get; set; }
       int Employee_Id { get; set; }
    }
}
