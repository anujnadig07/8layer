﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TYPES
{
    public interface IbgcBO
    {
        int CandidateID { get; set; }
        int BGCID { get; set; }
        int BGCTESTSTATUS { get; set; }
        int TestStatus { get; set; }
        string Remarks { get; set; }
    }
}
