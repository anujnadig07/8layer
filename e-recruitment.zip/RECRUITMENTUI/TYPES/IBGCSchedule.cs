﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TYPES
{
    public interface IBGCSchedule
    {
        int AdministratorID { get; set; }
        int BgcID { get; set; }
        DateTime StartDate { get; set; }
        DateTime EndDate { get; set; }
    }
}
