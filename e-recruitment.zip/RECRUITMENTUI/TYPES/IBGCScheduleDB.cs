﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TYPES
{
    public interface IBGCScheduleDB
    {
        List<IBGCSchedule> getBGCAdmin();
        int updateBGCSchedule(IBGCSchedule e);
        int deleteBGCSchedule(IBGCSchedule e);
    }
}
