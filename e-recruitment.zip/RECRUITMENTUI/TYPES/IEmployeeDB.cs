﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace TYPES
{
    public interface IEmployeeDB
    {
        int AddEmployee(IEmployeeBO obj);
        DataSet ViewEmployee();
        List<IEmployeeBO> ReadEmployee();
        List<IEmployeeBO> Readprojectid();
        DataSet GetcandidateDetails();

    }
}
