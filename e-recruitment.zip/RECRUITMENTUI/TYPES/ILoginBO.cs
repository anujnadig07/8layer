﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TYPES
{
    public interface ILoginBO
    {
        int Userid { get; set; }
        string Password { get; set; }
    }
}
