﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TYPES
{
    public interface ILoginDB
    {
        ILoginBO getPassword(ILoginBO e);
        int updatePassword(ILoginBO e);
        bool isHR(int a);
        bool isUnitHead(int a);
        int isBGCAdmin(int a);
    }
}
